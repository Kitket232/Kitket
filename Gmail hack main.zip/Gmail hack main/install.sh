g="\033[1;32m"
r="\033[1;31m"
b="\033[1;34m"
w="\033[0m"
o="\033[1;33m"

cd
cd
echo -e $w"["$g"INFO"$w"]"$b" Installing Gmail-Hack: Please wait a moment..."$w
apt install python
apt install python2
apt install python3
echo -e $w"["$g"INFO"$w"]"$b" Succesfull installed Gmail-Hack: Trank for installing..."$w
